#pragma once

#include "..\SDK\singleton.h"

class c_config : public singleton <c_config>
{
public:
};