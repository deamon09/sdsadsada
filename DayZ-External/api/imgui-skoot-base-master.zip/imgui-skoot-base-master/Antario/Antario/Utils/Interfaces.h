#pragma once
#include <Windows.h>


namespace interfaces
{
    // Used to initialize all the interfaces at one time
    void Init();
};