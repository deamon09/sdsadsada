#pragma once

namespace engine_prediction
{
    void RunEnginePred();
    void EndEnginePred();
}